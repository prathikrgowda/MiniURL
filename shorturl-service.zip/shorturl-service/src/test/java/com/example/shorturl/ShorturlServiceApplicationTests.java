package com.example.shorturl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShorturlServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
